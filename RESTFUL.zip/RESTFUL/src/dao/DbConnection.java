package dao;
 
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
 
public class DbConnection {
 
	public Connection getConnection() throws Exception
	{
		try
		{
			String connectionURL = "jdbc:oracle:thin:@localhost:1521:xe";
			String username = "system";
			String password = "system";
			Connection connection = null;
			Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
			connection = DriverManager.getConnection(connectionURL, username, password);
			return connection;
		}
		catch (SQLException e)
		{
			throw e;
		}
		catch (Exception e)
		{
			throw e;
		}
	}
 
}